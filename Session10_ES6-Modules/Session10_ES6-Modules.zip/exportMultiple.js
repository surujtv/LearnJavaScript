
export const myName = 'Surendra Jatav'

export let myAge = 25

export let address = {
    city: 'Indore',
    state: 'Madhya Pradesh'
}


export default function sayHi(){
    console.log('Hello World')
}

