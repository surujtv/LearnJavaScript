
// import myName from './Practice.mjs'
// import {object, arr as array, func} from './Practice.mjs'
// import {name as myName, object, arr, func} from './Practice.mjs'
import * as somethig from './Practice.mjs'


var name = 'Sandhya'
const Sandhya = 'Dwivedi'


console.log(somethig)
console.log(somethig.default)


// console.log(name)
// console.log(myName)

// console.log(object)
// // console.log(arr)

// console.log(array)
// console.log(func)
// func()


